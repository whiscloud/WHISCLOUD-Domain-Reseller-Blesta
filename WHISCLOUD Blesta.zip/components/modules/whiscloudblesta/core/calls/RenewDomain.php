<?php
namespace ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Calls;
use ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Call;

/**
 * Description of RenewDomain
 *
 * @author inbs
 */
class RenewDomain extends Call
{
    public $action = "order/domains/renew";
    
    public $type = parent::TYPE_POST;
}