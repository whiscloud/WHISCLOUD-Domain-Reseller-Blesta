<?php
namespace ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Calls;
use ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Call;

/**
 * Description of DeleteNameServer
 *
 * @author inbs
 */
class DeleteNameServer extends Call
{
    public $action = "domains/:domain/nameservers/delete";
    
    public $type = parent::TYPE_POST;
}