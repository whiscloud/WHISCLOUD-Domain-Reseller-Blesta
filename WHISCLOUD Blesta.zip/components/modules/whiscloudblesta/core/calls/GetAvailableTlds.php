<?php
namespace ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Calls;
use ModulesGarden\DomainsReseller\Registrar\whiscloudblesta\Core\Call;

/**
 * Description of GetAvailableTlds
 *
 * @author inbs
 */
class GetAvailableTlds extends Call
{
    public $action = "tlds";
    
    public $type = parent::TYPE_GET;
}