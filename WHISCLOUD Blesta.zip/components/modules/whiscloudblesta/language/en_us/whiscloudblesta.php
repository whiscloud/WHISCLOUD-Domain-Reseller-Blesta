<?php
// Basics
$lang['whiscloudblesta.name'] = 'whiscloudblesta';
$lang['whiscloudblesta.description'] = 'Resell domains with WHISCLOUD: low prices, Blesta integration, free SSL, and 24/7 support.';
$lang['whiscloudblesta.module_row'] = 'Account';
$lang['whiscloudblesta.module_row_plural'] = 'Accounts';

// Module management
$lang['whiscloudblesta.add_module_row'] = 'Add Account';
$lang['whiscloudblesta.manage.module_rows_title'] = 'Accounts';
$lang['whiscloudblesta.manage.module_rows_heading.user'] = 'User';
$lang['whiscloudblesta.manage.module_rows_heading.key'] = 'API Key';
$lang['whiscloudblesta.manage.module_rows_heading.endpoint'] = 'Endpoint';
$lang['whiscloudblesta.manage.module_rows_heading.options'] = 'Options';
$lang['whiscloudblesta.manage.module_rows.edit'] = 'Edit';
$lang['whiscloudblesta.manage.module_rows.delete'] = 'Delete';
$lang['whiscloudblesta.manage.module_rows.confirm_delete'] = 'Are you sure you want to delete this account?';
$lang['whiscloudblesta.manage.module_rows_no_results'] = 'There are no accounts.';

// Row Meta
$lang['whiscloudblesta.row_meta.user'] = 'User';
$lang['whiscloudblesta.row_meta.key'] = 'Key';
$lang['whiscloudblesta.row_meta.endpoint'] = 'Endpoint';

// Add row
$lang['whiscloudblesta.add_row.box_title'] = 'Add whiscloudblesta Account';
$lang['whiscloudblesta.add_row.basic_title'] = 'Basic Settings';
$lang['whiscloudblesta.add_row.add_btn'] = 'Add Account';

// Edit row
$lang['whiscloudblesta.edit_row.box_title'] = 'Edit whiscloudblesta Account';
$lang['whiscloudblesta.edit_row.basic_title'] = 'Basic Settings';
$lang['whiscloudblesta.edit_row.add_btn'] = 'Update Account';

// Package fields
$lang['whiscloudblesta.package_fields.type'] = 'Type';
$lang['whiscloudblesta.package_fields.type_domain.register'] = 'Domain Registration';
$lang['whiscloudblesta.package_fields.type_domain.transfer'] = 'Domain Transfer';
$lang['whiscloudblesta.package_fields.type_domain.renew'] = 'Domain Renew';
$lang['whiscloudblesta.package_fields.tld_options'] = 'TLDs';
$lang['whiscloudblesta.package_fields.ns1'] = 'Name Server 1';
$lang['whiscloudblesta.package_fields.ns2'] = 'Name Server 2';
$lang['whiscloudblesta.package_fields.ns3'] = 'Name Server 3';
$lang['whiscloudblesta.package_fields.ns4'] = 'Name Server 4';
$lang['whiscloudblesta.package_fields.ns5'] = 'Name Server 5';

// Service management
$lang['whiscloudblesta.tab_whois.title'] = 'Whois';
$lang['whiscloudblesta.tab_whois.section_Registrant'] = 'Registrant';
$lang['whiscloudblesta.tab_whois.section_Admin'] = 'Administrative';
$lang['whiscloudblesta.tab_whois.section_Tech'] = 'Technical';
$lang['whiscloudblesta.tab_whois.section_AuxBilling'] = 'Billing';
$lang['whiscloudblesta.tab_whois.field_submit'] = 'Update Whois';

$lang['whiscloudblesta.tab_nameservers.title'] = 'Name Servers';
$lang['whiscloudblesta.tab_nameserver.field_ns'] = 'Name Server %1$s'; // %1$s is the name server number
$lang['whiscloudblesta.tab_nameservers.field_submit'] = 'Update Name Servers';

$lang['whiscloudblesta.tab_settings.title'] = 'Settings';
$lang['whiscloudblesta.tab_settings.field_registrar_lock'] = 'Registrar Lock';
$lang['whiscloudblesta.tab_settings.field_registrar_lock_yes'] = 'Set the registrar lock. Recommended to prevent unauthorized transfer.';
$lang['whiscloudblesta.tab_settings.field_registrar_lock_no'] = 'Release the registrar lock so the domain can be transferred.';
$lang['whiscloudblesta.tab_settings.field_request_epp'] = 'Request EPP Code/Transfer Key';
$lang['whiscloudblesta.tab_settings.field_submit'] = 'Update Settings';

// Errors
$lang['whiscloudblesta.!error.user.valid'] = 'Please enter a user';
$lang['whiscloudblesta.!error.key.valid'] = 'Please enter a key';
$lang['whiscloudblesta.!error.key.valid_connection'] = 'The user and key combination appear to be invalid, or your whiscloudblesta account may not be configured to allow API access.';

// Domain Transfer Fields
$lang['whiscloudblesta.transfer.domain'] = 'Domain Name';
$lang['whiscloudblesta.transfer.EPPCode'] = 'EPP Code';

// Domain Fields
$lang['whiscloudblesta.domain.domain'] = 'Domain Name';
$lang['whiscloudblesta.domain.Years'] = 'Years';

// Nameserver Fields
$lang['whiscloudblesta.nameserver.ns1'] = 'Name Server 1';
$lang['whiscloudblesta.nameserver.ns2'] = 'Name Server 2';
$lang['whiscloudblesta.nameserver.ns3'] = 'Name Server 3';
$lang['whiscloudblesta.nameserver.ns4'] = 'Name Server 4';
$lang['whiscloudblesta.nameserver.ns5'] = 'Name Server 5';

// Whois Fields
$lang['whiscloudblesta.whois.RegistrantFirstName'] = 'First Name';
$lang['whiscloudblesta.whois.RegistrantLastName'] = 'Last Name';
$lang['whiscloudblesta.whois.RegistrantAddress1'] = 'Address 1';
$lang['whiscloudblesta.whois.RegistrantAddress2'] = 'Address 2';
$lang['whiscloudblesta.whois.RegistrantCity'] = 'City';
$lang['whiscloudblesta.whois.RegistrantStateProvince'] = 'State/Province';
$lang['whiscloudblesta.whois.RegistrantPostalCode'] = 'Postal Code';
$lang['whiscloudblesta.whois.RegistrantCountry'] = 'Country';
$lang['whiscloudblesta.whois.RegistrantPhone'] = 'Phone';
$lang['whiscloudblesta.whois.RegistrantEmailAddress'] = 'Email';

$lang['whiscloudblesta.whois.TechFirstName'] = 'First Name';
$lang['whiscloudblesta.whois.TechLastName'] = 'Last Name';
$lang['whiscloudblesta.whois.TechAddress1'] = 'Address 1';
$lang['whiscloudblesta.whois.TechAddress2'] = 'Address 2';
$lang['whiscloudblesta.whois.TechCity'] = 'City';
$lang['whiscloudblesta.whois.TechStateProvince'] = 'State/Province';
$lang['whiscloudblesta.whois.TechPostalCode'] = 'Postal Code';
$lang['whiscloudblesta.whois.TechCountry'] = 'Country';
$lang['whiscloudblesta.whois.TechPhone'] = 'Phone';
$lang['whiscloudblesta.whois.TechEmailAddress'] = 'Email';

$lang['whiscloudblesta.whois.AdminFirstName'] = 'First Name';
$lang['whiscloudblesta.whois.AdminLastName'] = 'Last Name';
$lang['whiscloudblesta.whois.AdminAddress1'] = 'Address 1';
$lang['whiscloudblesta.whois.AdminAddress2'] = 'Address 2';
$lang['whiscloudblesta.whois.AdminCity'] = 'City';
$lang['whiscloudblesta.whois.AdminStateProvince'] = 'State/Province';
$lang['whiscloudblesta.whois.AdminPostalCode'] = 'Postal Code';
$lang['whiscloudblesta.whois.AdminCountry'] = 'Country';
$lang['whiscloudblesta.whois.AdminPhone'] = 'Phone';
$lang['whiscloudblesta.whois.AdminEmailAddress'] = 'Email';

$lang['whiscloudblesta.whois.AuxBillingFirstName'] = 'First Name';
$lang['whiscloudblesta.whois.AuxBillingLastName'] = 'Last Name';
$lang['whiscloudblesta.whois.AuxBillingAddress1'] = 'Address 1';
$lang['whiscloudblesta.whois.AuxBillingAddress2'] = 'Address 2';
$lang['whiscloudblesta.whois.AuxBillingCity'] = 'City';
$lang['whiscloudblesta.whois.AuxBillingStateProvince'] = 'State/Province';
$lang['whiscloudblesta.whois.AuxBillingPostalCode'] = 'Postal Code';
$lang['whiscloudblesta.whois.AuxBillingCountry'] = 'Country';
$lang['whiscloudblesta.whois.AuxBillingPhone'] = 'Phone';
$lang['whiscloudblesta.whois.AuxBillingEmailAddress'] = 'Email';


// Errors
$lang['whiscloudblesta.!error.FRLegalType.format'] = 'Please select a valid Legal Type';
$lang['whiscloudblesta.!error.FRRegistrantBirthDate.format'] = 'Please set your birth date in the format: YYYY-MM-DD';
$lang['whiscloudblesta.!error.FRRegistrantBirthplace.format'] = 'Please set your birth place.';
$lang['whiscloudblesta.!error.FRRegistrantLegalId.format'] = 'Please set your SIREN/SIRET Number';
$lang['whiscloudblesta.!error.FRRegistrantTradeNumber.format'] = 'Please set your Trademark Number.';
$lang['whiscloudblesta.!error.FRRegistrantDunsNumber.format'] = 'Please set your DUNS Number.';
$lang['whiscloudblesta.!error.FRRegistrantLocalId.format'] = 'Please set your EEA Local ID.';
$lang['whiscloudblesta.!error.FRRegistrantJoDateDec.format'] = 'Please set the Journal Declaration Date in the format: YYYY-MM-DD';
$lang['whiscloudblesta.!error.FRRegistrantJoDatePub.format'] = 'Please set the Journal Publication Date in the format: YYYY-MM-DD';
$lang['whiscloudblesta.!error.FRRegistrantJoNumber.format'] = 'Please set the Journal Number.';
$lang['whiscloudblesta.!error.FRRegistrantJoPage.format'] = 'Please set the Journal Announcement Page Number.';
