<?php
// Transfer fields
Configure::set('whiscloudblesta.transfer_fields',
[
    'domain' =>
    [
        'label' => Language::_('whiscloudblesta.transfer.domain', true),
        'type' => 'text'
    ],
    'EPPCode' =>
    [
        'label' => Language::_('whiscloudblesta.transfer.EPPCode', true),
        'type' => 'text'
    ]
]);

// Domain fields
Configure::set('whiscloudblesta.domain_fields',
[
    'domain' =>
    [
        'label' => Language::_('whiscloudblesta.domain.domain', true),
        'type' => 'text'
    ],
]);

// Nameserver fields
Configure::set('whiscloudblesta.nameserver_fields',
[
    'ns1' =>
    [
        'label' => Language::_('whiscloudblesta.nameserver.ns1', true),
        'type' => 'text'
    ],
    'ns2' =>
    [
        'label' => Language::_('whiscloudblesta.nameserver.ns2', true),
        'type' => 'text'
    ],
    'ns3' =>
    [
        'label' => Language::_('whiscloudblesta.nameserver.ns3', true),
        'type' => 'text'
    ],
    'ns4' =>
    [
        'label' => Language::_('whiscloudblesta.nameserver.ns4', true),
        'type' => 'text'
    ],
    'ns5' =>
    [
        'label' => Language::_('whiscloudblesta.nameserver.ns5', true),
        'type' => 'text'
    ]
]);

// Whois fields
Configure::set('whiscloudblesta.whois_fields',
[
    "registrant"    =>
    [
        'firstname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantFirstName', true),
            'type' => 'text'
        ],
        'lastname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantLastName', true),
            'type' => 'text'
        ],
        'fullname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantFullname', true),
            'type' => 'text'
        ],
        'companyname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantCompanyName', true),
            'type' => 'text'
        ],
        'email' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantEmail', true),
            'type' => 'text'
        ],
        'address1' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantAddress1', true),
            'type' => 'text'
        ],
        'address2' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantAddress2', true),
            'type' => 'text'
        ],
        'city' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantCity', true),
            'type' => 'text'
        ],
        'state' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantState', true),
            'type' => 'text'
        ],
        'zipcode' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantZipCode', true),
            'type' => 'text'
        ],
        'country' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantCountry', true),
            'type' => 'text'
        ],
        'phone' =>
        [
            'label' => Language::_('whiscloudblesta.whois.RegistrantPhone', true),
            'type' => 'text'
        ],
    ],

    "tech"       =>
    [
        'firstname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechFirstName', true),
            'type' => 'text'
        ],
        'lastname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechLastName', true),
            'type' => 'text'
        ],
        'fullname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechFullname', true),
            'type' => 'text'
        ],
        'companyname' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechCompanyName', true),
            'type' => 'text'
        ],
        'email' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechEmail', true),
            'type' => 'text'
        ],
        'address1' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechAddress1', true),
            'type' => 'text'
        ],
        'address2' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechAddress2', true),
            'type' => 'text'
        ],
        'city' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechCity', true),
            'type' => 'text'
        ],
        'state' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechState', true),
            'type' => 'text'
        ],
        'zipcode' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechZipCode', true),
            'type' => 'text'
        ],
        'country' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechCountry', true),
            'type' => 'text'
        ],
        'phone' =>
        [
            'label' => Language::_('whiscloudblesta.whois.TechPhone', true),
            'type' => 'text'
        ],
    ]
]
);

// All available TLDs
Configure::set('whiscloudblesta.tlds', [
    '.co.uk',
    '.com.au',
    '.com.es',
]);